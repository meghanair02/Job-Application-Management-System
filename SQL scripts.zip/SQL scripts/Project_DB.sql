SELECT 
    jc.category_name, 
    COUNT(a.application_id) AS total_applications
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp 
    ON a.job_id = jp.job_id
JOIN 
    job_categories_clean jc 
    ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name
ORDER BY 
    total_applications DESC;




SELECT DISTINCT js.seeker_id, js.first_name, js.last_name, js.email, e.gpa, wa.auth_type AS work_authorization
FROM job_seekers js
JOIN education e ON js.seeker_id = e.seeker_id
JOIN work_authorization wa ON js.work_auth_id = wa.work_auth_id
WHERE 
    e.gpa >= 3
ORDER BY 
    e.gpa DESC;






SELECT 
    jc.category_name, l.state, 
    ROUND(AVG(CAST(REPLACE(REPLACE(SUBSTRING_INDEX(jp.salary_range, '-', -1), '$', ''), 'k', '') AS UNSIGNED) * 1000), 2) AS avg_salary
FROM 
    job_postings_clean jp
JOIN 
    job_categories_clean jc 
    ON jp.category_id = jc.category_id
JOIN 
    locations l 
    ON jp.zipcode = l.zipcode
GROUP BY 
    jc.category_name, l.state
ORDER BY 
    avg_salary DESC;
    
    
    
    
    SELECT 
    k.keyword, 
    COUNT(jp.job_id) AS usage_count
FROM 
    keywords k
JOIN 
    job_postings_clean jp 
    ON k.keyword_id = jp.keyword_id
WHERE 
    STR_TO_DATE(jp.expire_on, '%Y-%m-%d') > CURDATE()
GROUP BY 
    k.keyword
ORDER BY 
    usage_count DESC
LIMIT 10;





SELECT 
    l.city, 
    l.state, 
    COUNT(jp.job_id) AS total_jobs
FROM 
    job_postings_clean jp
JOIN 
    locations l 
    ON jp.zipcode = l.zipcode
GROUP BY 
    l.city, l.state
ORDER BY 
    total_jobs DESC
LIMIT 1;







WITH seeker_skills AS (
    SELECT 
        js.seeker_id, js.first_name, js.last_name,
        js.zip_code AS seeker_location,
        js.work_auth_id,
        js.exp_level AS seeker_experience
    FROM job_seekers js
),
job_requirements AS (
    SELECT 
        jp.job_id, jp.job_title,
        jp.zipcode AS job_location, jp.work_auth_id,
        jp.category_id AS job_experience,
        k.keyword AS required_skill
    FROM job_postings_clean jp
    JOIN keywords k ON jp.keyword_id = k.keyword_id
),
compatibility AS (
    SELECT 
        ss.seeker_id, ss.first_name, ss.last_name, jr.job_id, jr.job_title,
        -- Skill Matching (50% Weight)
        0.5 AS skill_match,
        -- Location Match (20% Weight)
        CASE WHEN ss.seeker_location = jr.job_location THEN 1 ELSE 0 END * 0.2 AS location_match,
        -- Experience Match (20% Weight)
        CASE 
            WHEN ss.seeker_experience >= jr.job_experience THEN 1 
            WHEN ABS(ss.seeker_experience - jr.job_experience) <= 1 THEN 0.5
            ELSE 0
        END * 0.2 AS experience_match,
        -- Work Authorization Match (10% Weight)
        CASE WHEN ss.work_auth_id = jr.work_auth_id THEN 1 ELSE 0 END * 0.1 AS auth_match
    FROM seeker_skills ss
    CROSS JOIN job_requirements jr
),
ranked_matches AS (
    SELECT 
        seeker_id, first_name, last_name, job_id, job_title,
        (skill_match + location_match + experience_match + auth_match) AS compatibility_score
    FROM compatibility
)
SELECT *
FROM ranked_matches
WHERE compatibility_score >= 0.7 -- Only show matches with 70%+ compatibility
ORDER BY compatibility_score DESC, seeker_id;



SELECT 
    jc.category_name, 
    COUNT(p.perk_id) AS total_benefits
FROM 
    job_postings_clean jp
JOIN 
    perks p 
    ON jp.perks_id = p.perk_id
JOIN 
    job_categories_clean jc 
    ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name
ORDER BY 
    total_benefits DESC
LIMIT 5;




USE jobapplication_database; -- Specify the database name

WITH aggregated_experience AS (
    SELECT 
        seeker_id, 
        SUM(months_of_experience) AS total_experience
    FROM 
        seeker_experience
    GROUP BY 
        seeker_id
)
SELECT 
    a.job_id, js.seeker_id, js.first_name, js.last_name, e.gpa, ae.total_experience
FROM 
    applications_clean a
JOIN 
    job_seekers js 
    ON a.seeker_id = js.seeker_id
JOIN 
    education e 
    ON js.seeker_id = e.seeker_id
JOIN 
    aggregated_experience ae 
    ON js.seeker_id = ae.seeker_id
WHERE 
    a.job_id = '171' -- Replace with the desired job ID
ORDER BY 
    CAST(ae.total_experience AS UNSIGNED) DESC, 
    CAST(e.gpa AS DECIMAL(10, 2)) DESC
LIMIT 
    3;



SELECT 
    jc.category_name,
    SUM(CASE WHEN a.application_status = 'Applied' THEN 1 ELSE 0 END) AS Applied,
    SUM(CASE WHEN a.application_status = 'Under Review' THEN 1 ELSE 0 END) AS Under_Review,
    SUM(CASE WHEN a.application_status = 'Rejected' THEN 1 ELSE 0 END) AS Rejected,
    SUM(CASE WHEN a.application_status = 'Accepted' THEN 1 ELSE 0 END) AS Accepted
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp 
    ON a.job_id = jp.job_id
JOIN 
    job_categories_clean jc 
    ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name
ORDER BY 
    jc.category_name;
    
    
    SELECT 
    jc.category_name,
    wa.auth_type AS work_authorization,
    COUNT(a.application_id) AS application_count
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp 
    ON a.job_id = jp.job_id
JOIN 
    job_categories_clean jc 
    ON jp.category_id = jc.category_id
JOIN 
    work_authorization wa 
    ON jp.work_auth_id = wa.work_auth_id
GROUP BY 
    jc.category_name, wa.auth_type
ORDER BY 
    jc.category_name, application_count DESC;
    
    
    
    
    
    
SELECT 
    jc.category_name, 
    COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) * 100.0 / COUNT(*) AS conversion_rate
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp ON a.job_id = jp.job_id
JOIN 
    job_categories_clean jc ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name
ORDER BY 
    conversion_rate DESC;


SELECT 
    jc.category_name, 
    COUNT(CASE WHEN a.application_status = 'Rejected' THEN 1 END) AS rejection_count
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp ON a.job_id = jp.job_id
JOIN 
    job_categories_clean jc ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name
ORDER BY 
    rejection_count DESC
LIMIT 10;






  SELECT 
        k.keyword, 
        COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) * 100.0 / COUNT(*) AS conversion_rate
    FROM 
        applications_clean a
    JOIN 
        job_postings_clean jp ON a.job_id = jp.job_id
    JOIN 
        keywords k ON jp.keyword_id = k.keyword_id
    GROUP BY 
        k.keyword
    ORDER BY 
        conversion_rate DESC
    LIMIT 10;
    
    
    
    
    
    
SELECT 
    jc.category_name, 
    COUNT(a.application_id) AS total_applications, 
    COUNT(DISTINCT jp.job_id) AS job_openings,
    ROUND(COUNT(a.application_id) / COUNT(DISTINCT jp.job_id), 2) AS application_to_opening_ratio
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp ON a.job_id = jp.job_id
JOIN 
    job_categories_clean jc ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name
ORDER BY 
    application_to_opening_ratio DESC;





SELECT 
    jc.category_name, 
    wa.auth_type, 
    COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) * 100.0 / COUNT(*) AS acceptance_rate
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp ON a.job_id = jp.job_id
JOIN 
    work_authorization wa ON jp.work_auth_id = wa.work_auth_id
JOIN 
    job_categories_clean jc ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name, wa.auth_type
ORDER BY 
    acceptance_rate DESC;




SELECT 
    e.field_of_study, 
    COUNT(a.application_id) AS total_accepted_applicants
FROM 
    applications_clean a
JOIN 
    education e 
    ON a.seeker_id = e.seeker_id
WHERE 
    a.application_status = 'Accepted'
GROUP BY 
    e.field_of_study
ORDER BY 
    total_accepted_applicants DESC
LIMIT 3;





SELECT 
    se.company_name, 
    COUNT(se.company_name) AS total_job_postings
FROM 
    seeker_experience se
GROUP BY 
    se.company_name
ORDER BY 
    total_job_postings DESC
LIMIT 1;





WITH monthly_applications AS (
    SELECT 
        DATE_FORMAT(a.application_date, '%Y-%m') AS application_month,
        COUNT(a.application_id) AS total_applications
    FROM 
        applications_clean a
    GROUP BY 
        DATE_FORMAT(a.application_date, '%Y-%m')
),
monthly_growth AS (
    SELECT 
        ma.application_month, ma.total_applications, ma.total_applications - LAG(ma.total_applications) OVER (ORDER BY ma.application_month) AS monthly_growth
    FROM 
        monthly_applications ma
)
SELECT 
    application_month, total_applications, monthly_growth
FROM 
    monthly_growth
ORDER BY 
    monthly_growth DESC
LIMIT 5;


SELECT 
    js.seeker_id,
    js.first_name,
    js.last_name,
    COUNT(a.application_id) AS total_applications,
    COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) AS accepted_applications,
    ROUND((COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) * 100.0) / COUNT(a.application_id), 2) AS acceptance_percentage
FROM 
    job_seekers js
JOIN 
    applications_clean a 
    ON js.seeker_id = a.seeker_id
GROUP BY 
    js.seeker_id, js.first_name, js.last_name
ORDER BY 
    acceptance_percentage DESC, total_applications DESC;




SELECT 
    jc.category_name,
    COUNT(a.application_id) AS total_applications,
    COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) AS accepted_applications,
    ROUND(COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) * 100.0 / COUNT(a.application_id), 2) AS acceptance_ratio
FROM 
    applications_clean a
JOIN 
    job_postings_clean jp 
    ON a.job_id = jp.job_id
JOIN 
    job_categories_clean jc 
    ON jp.category_id = jc.category_id
GROUP BY 
    jc.category_name
ORDER BY 
    acceptance_ratio ASC, total_applications DESC;






SELECT 
    js.gender,
    COUNT(a.application_id) AS total_applications,
    COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) AS accepted_applications,
    ROUND(COUNT(CASE WHEN a.application_status = 'Accepted' THEN 1 END) * 100.0 / COUNT(a.application_id), 2) AS acceptance_rate
FROM 
    job_seekers js
JOIN 
    applications_clean a 
    ON js.seeker_id = a.seeker_id
GROUP BY 
    js.gender
ORDER BY 
    acceptance_rate DESC;
