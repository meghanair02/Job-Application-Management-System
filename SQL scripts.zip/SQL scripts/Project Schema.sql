-- Step 1: Create the database
CREATE DATABASE IF NOT EXISTS JobApplication_database;
USE JobApplication_database;

-- ################## Admins Folder ##################

-- Table: Admin Users
CREATE TABLE admin_users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    email VARCHAR(255),
    status VARCHAR(50),
    registration_date DATE,
    last_login DATE
);

-- Table: Admin Recruiters
CREATE TABLE admin_recruiters (
    recruiter_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    assigned_job_postings TEXT
);

-- Table: Admin Job Postings
CREATE TABLE Admin_job_postings (
    job_id INT PRIMARY KEY AUTO_INCREMENT,
    job_title VARCHAR(255),
    number_of_open_positions INT,
    posting_date DATE,
    application_deadline DATE,
    job_status VARCHAR(50),
    recruiter_assigned VARCHAR(255),
    department VARCHAR(255)
);

-- ################## USERS UPDATED 2 Folder ##################

-- Table: Education
CREATE TABLE education (
    education_id VARCHAR(50),
    seeker_id VARCHAR(50),
    institution_name VARCHAR(200),
    degree VARCHAR(100),
    field_of_study VARCHAR(100),
    credit_hours INT,
    gpa INT
);

-- Table: Applications Clean
CREATE TABLE applications_clean (
    application_id VARCHAR(100),
    job_id VARCHAR(100),
    seeker_id VARCHAR(100),
    application_status VARCHAR(50),
    application_date DATE
);

-- Table: Job Seekers
CREATE TABLE job_seekers (
    seeker_id VARCHAR(100),
    zipcode INT,
    work_auth_id INT,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
	phone VARCHAR(50),
    email VARCHAR(200),
    edu_level VARCHAR(200),
    exp_level INT,
    age INT,
    gender VARCHAR(50),
    schools VARCHAR(100)
);

-- Table: Work Authorization
CREATE TABLE work_authorization (
    work_auth_id INT PRIMARY KEY AUTO_INCREMENT,
    auth_type VARCHAR(100)
);

-- Table: Locations
CREATE TABLE locations (
    zipcode INT,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100)
);

-- Table: Perks
CREATE TABLE perks (
    perk_id INT PRIMARY KEY AUTO_INCREMENT,
    perk_name VARCHAR(100)
);

-- Table: Job Titles
CREATE TABLE job_titles (
    job_title_id INT PRIMARY KEY AUTO_INCREMENT,
    job_title VARCHAR(100)
);

-- Table: Keywords
CREATE TABLE keywords (
    keyword_id INT PRIMARY KEY AUTO_INCREMENT,
    keyword VARCHAR(100)
);

-- Table: Employees
CREATE TABLE employers (
    employer_id VARCHAR(100),
    zipcode INT,
    company_name VARCHAR(100),
    recruiting_manager VARCHAR(100),
    industry VARCHAR(100),
    date_posted Date
);

-- Table: Job Postings Clean
CREATE TABLE job_postings_clean (
    job_id INT PRIMARY KEY AUTO_INCREMENT,
    work_auth_id INT,
    category_id INT,
    zipcode INT,
    job_title VARCHAR(200),
    employer_id VARCHAR(200),
    keyword_id INT,
    job_type VARCHAR(200),
    salary_range VARCHAR(200),
    perks_id INT,
    posted_on Date,
    expire_on Date
);

-- Table: Seeker Experience
CREATE TABLE seeker_experience (
    experience_id VARCHAR(100),
    seeker_id VARCHAR(100),
	start_date DATE,
    end_date DATE,
    job_title VARCHAR(100),
    company_name VARCHAR(200),
    months_of_experience INT
);

-- Table: Job Categories Clean
CREATE TABLE job_categories_clean (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100)
);