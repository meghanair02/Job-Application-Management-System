import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Job } from '../types/job';

interface JobContextType {
  jobs: Job[];
  loading: boolean;
  error: string | null;
  addJob: (job: Omit<Job, 'job_id' | 'applicationCount'>) => void;
  updateJob: (job: Job) => void;
  deleteJob: (jobId: number) => void;
}

const JobContext = createContext<JobContextType | undefined>(undefined);

export function JobProvider({ children }: { children: ReactNode }) {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchJobs();
  }, []);

  const addJob = (newJob: Omit<Job, 'job_id' | 'applicationCount'>) => {
    const job: Job = {
      ...newJob,
      job_id: Date.now(),
      applicationCount: 0
    };
    setJobs([...jobs, job]);
  };

  const updateJob = (updatedJob: Job) => {
    setJobs(jobs.map(job => job.job_id === updatedJob.job_id ? updatedJob : job));
  };

  const deleteJob = (jobId: number) => {
    setJobs(jobs.filter(job => job.job_id !== jobId));
  };

  const fetchJobs = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/job-roles');
      if (!response.ok) throw new Error('Failed to fetch jobs');
      const data = await response.json();
      console.log('Fetched jobs:', data); // Debug log
      
      // Set all jobs without filtering
      setJobs(data);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <JobContext.Provider value={{ 
      jobs, 
      loading, 
      error,
      addJob, 
      updateJob, 
      deleteJob 
    }}>
      {children}
    </JobContext.Provider>
  );
}

export function useJobs() {
  const context = useContext(JobContext);
  if (context === undefined) {
    throw new Error('useJobs must be used within a JobProvider');
  }
  return context;
}