import { FC } from 'react';
import { Job } from '../types/job';
import { Briefcase, MapPin, DollarSign, Calendar, Clock, Edit, Trash2 } from 'lucide-react';
import { ApplyButton } from './ApplyButton';
import { useAuth } from '../context/AuthContext';

interface JobCardProps {
  job: Job;
  onEdit?: ((job: Job) => void) | undefined;
  onDelete?: ((id: number) => void) | undefined;
}

export const JobCard: FC<JobCardProps> = ({ job, onEdit, onDelete }) => {
  const { isAdmin } = useAuth();
  const isExpired = new Date(job.expire_on || '').getTime() < new Date().getTime();

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-gray-800">{job.job_title}</h3>
          
          <div className="flex items-center text-gray-600 mt-2">
            <Briefcase className="w-4 h-4 mr-2" />
            <span>{job.job_type}</span>
          </div>
          
          <div className="flex items-center text-gray-600 mt-1">
            <MapPin className="w-4 h-4 mr-2" />
            <span>Zipcode: {job.zipcode || 'N/A'}</span>
          </div>
          
          <div className="flex items-center text-gray-600 mt-1">
            <DollarSign className="w-4 h-4 mr-2" />
            <span>{job.salary_range || 'Not specified'}</span>
          </div>
          
          <div className="flex items-center text-gray-600 mt-1">
            <Calendar className="w-4 h-4 mr-2" />
            <span>Posted: {job.posted_on || 'N/A'}</span>
          </div>
          
          <div className="flex items-center text-gray-600 mt-1">
            <Clock className="w-4 h-4 mr-2" />
            <span className={isExpired ? 'text-red-600' : 'text-green-600'}>
              {isExpired ? 'Expired' : `Expires: ${job.expire_on || 'N/A'}`}
            </span>
          </div>
        </div>
        
        {isAdmin && onEdit && onDelete && job.job_id && (
          <div className="flex space-x-2">
            <button
              onClick={() => onEdit(job)}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-full"
              type="button"
            >
              <Edit className="w-5 h-5" />
            </button>
            <button
              onClick={() => onDelete(job.job_id)}
              className="p-2 text-red-600 hover:bg-red-50 rounded-full"
              type="button"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
      
      <div className="mt-4 flex justify-between items-center">
        <div className="text-sm text-gray-500">
          Posted: {job.posted_on ? new Date(job.posted_on).toLocaleDateString() : 'N/A'}
        </div>
        {job.job_id && <ApplyButton jobId={job.job_id} seekerId={1} />}
      </div>
    </div>
  );
};