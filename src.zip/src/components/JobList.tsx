import React from 'react';
import { Job } from '../types/job';
import { JobCard } from './JobCard';
import { useAuth } from '../context/AuthContext';

interface JobListProps {
  jobs: Job[];
  onEdit?: (job: Job) => void;
  onDelete?: (id: number) => void;
}

export function JobList({ jobs, onEdit, onDelete }: JobListProps) {
  const { isAdmin } = useAuth();

  if (!jobs?.length) {
    return (
      <div className="text-center py-8 text-gray-500">
        No jobs found
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {jobs.map((job) => (
        <JobCard
          key={job.job_id?.toString() || Math.random().toString()}
          job={job}
          onEdit={isAdmin && onEdit ? onEdit : undefined}
          onDelete={isAdmin && onDelete ? onDelete : undefined}
        />
      ))}
    </div>
  );
}