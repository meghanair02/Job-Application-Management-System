import { useEffect, useState } from 'react';
import { Users, Briefcase, Clock, CheckCircle } from 'lucide-react';

interface Stats {
  totalApplications: number;
  activeJobs: number;
  pendingApplications: number;
  completedApplications: number;
}

export function DashboardStats() {
  const [stats, setStats] = useState<Stats>({
    totalApplications: 0,
    activeJobs: 0,
    pendingApplications: 0,
    completedApplications: 0
  });

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/analytics');
      if (!response.ok) throw new Error('Failed to fetch stats');
      const data = await response.json();

      setStats({
        totalApplications: data.totalApplications || 0,
        activeJobs: data.totalJobs || 0,
        pendingApplications: data.pendingApplications || 0,
        completedApplications: data.completedApplications || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        title="Total Applications"
        value={stats.totalApplications}
        icon={<Users className="h-6 w-6 text-blue-600" />}
      />
      <StatCard
        title="Available Jobs"
        value={stats.activeJobs}
        icon={<Briefcase className="h-6 w-6 text-green-600" />}
      />
      <StatCard
        title="Pending Applications"
        value={stats.pendingApplications}
        icon={<Clock className="h-6 w-6 text-yellow-600" />}
      />
      <StatCard
        title="Completed Applications"
        value={stats.completedApplications}
        icon={<CheckCircle className="h-6 w-6 text-purple-600" />}
      />
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center justify-between">
        {icon}
        <div className="text-right">
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="mt-2 text-3xl font-semibold text-gray-900">{value}</p>
        </div>
      </div>
    </div>
  );
}