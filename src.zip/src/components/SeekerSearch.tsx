import React, { useState } from 'react';

interface Seeker {
  seeker_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  edu_level: string;
}

export function SeekerSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [seekers, setSeekers] = useState<Seeker[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!searchTerm) return;

    setLoading(true);
    try {
      const response = await fetch(`http://localhost:3000/api/applications/search?name=${encodeURIComponent(searchTerm)}`);
      if (!response.ok) throw new Error('Search failed');
      const data = await response.json();
      setSeekers(data);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by name..."
          className="flex-1 px-4 py-2 border border-gray-300 rounded-md"
        />
        <button
          onClick={handleSearch}
          disabled={loading}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          {loading ? 'Searching...' : 'Search'}
        </button>
      </div>

      {seekers.length > 0 && (
        <div className="mt-4">
          <h3 className="text-lg font-medium mb-2">Search Results</h3>
          <div className="space-y-2">
            {seekers.map((seeker) => (
              <div key={seeker.seeker_id} className="p-4 border rounded-md">
                <div className="font-medium">{seeker.first_name} {seeker.last_name}</div>
                <div className="text-sm text-gray-600">{seeker.email}</div>
                <div className="text-sm text-gray-600">Education: {seeker.edu_level}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
} 