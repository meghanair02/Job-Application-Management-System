import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ApplicationForm } from './ApplicationForm';

interface ApplyButtonProps {
  jobId: number;
  seekerId?: number;
}

export function ApplyButton({ jobId }: ApplyButtonProps) {
  const [showForm, setShowForm] = useState(false);
  const navigate = useNavigate();

  const handleClick = () => {
    setShowForm(true);
  };

  return (
    <>
      <button
        onClick={handleClick}
        className="px-4 py-2 rounded-md text-white font-medium bg-blue-600 hover:bg-blue-700"
      >
        Apply Now
      </button>

      {showForm && (
        <ApplicationForm
          jobId={jobId}
          onClose={() => setShowForm(false)}
        />
      )}
    </>
  );
}