export interface Application {
  application_id: number;
  seeker_name: string;
  seeker_email: string;
  application_status: string;
  application_date: string;
} 