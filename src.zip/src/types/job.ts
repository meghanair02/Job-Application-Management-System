export interface Job {
  job_id: number;
  job_title: string;
  job_type: string;
  salary_range: string;
  posted_on: string;
  expire_on: string;
  zipcode?: number;
  work_auth_id?: number;
  category_id?: number;
  employer_id?: number;
  keyword_id?: number;
  perks_id?: number;
  applicationCount: number;
}