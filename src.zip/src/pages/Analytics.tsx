import { useEffect, useState } from 'react';
import { Briefcase, Users, TrendingUp, MapPin } from 'lucide-react';

interface AnalyticsData {
  totalJobs: number;
  jobCategories: Array<{ category_name: string; count: number }>;
  jobTypeDistribution: Array<{ job_type: string; count: number }>;
  locationStats: Array<{ zipcode: string; count: number }>;
  salaryRanges: Array<{ range: string; count: number }>;
  applicationSuccess: {
    completed: number;
    pending: number;
    rejected: number;
    accepted: number;
    rate: string;
  };
  monthlyTrends: Array<{
    month: string;
    applications: number;
    jobs: number;
  }>;
  activeLocations: number;
  totalApplications: number;
  completedApplications: number;
  pendingApplications: number;
}

export function Analytics() {
  const [data, setData] = useState<AnalyticsData>({
    totalJobs: 0,
    jobCategories: [],
    jobTypeDistribution: [],
    locationStats: [],
    salaryRanges: [],
    applicationSuccess: { completed: 0, pending: 0, rejected: 0, accepted: 0, rate: '0' },
    monthlyTrends: [],
    activeLocations: 0,
    totalApplications: 0,
    completedApplications: 0,
    pendingApplications: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/analytics');
      if (!response.ok) throw new Error('Failed to fetch analytics');
      const analyticsData = await response.json();
      console.log('Received analytics data:', analyticsData);
      setData(analyticsData);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center items-center h-64">Loading...</div>;
  if (error) return <div className="text-red-600 text-center">{error}</div>;

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900 mb-8">Analytics Dashboard</h1>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <SummaryCard
            title="Total Jobs Posted"
            value={data.totalJobs}
            icon={<Briefcase className="h-8 w-8 text-blue-500" />}
          />
          <SummaryCard
            title="Total Applications"
            value={data.applicationSuccess.completed + data.applicationSuccess.pending + data.applicationSuccess.rejected}
            icon={<Users className="h-8 w-8 text-green-500" />}
          />
          <SummaryCard
            title="Success Rate"
            value={`${data.applicationSuccess.rate}%`}
            icon={<TrendingUp className="h-8 w-8 text-purple-500" />}
          />
          <SummaryCard
            title="Active Locations"
            value={data.activeLocations}
            icon={<MapPin className="h-8 w-8 text-red-500" />}
          />
        </div>

        {/* Data Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Job Categories */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Job Categories</h2>
            <div className="space-y-2">
              {data.jobCategories.map((category, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-gray-600">{category.category_name}</span>
                  <span className="font-medium">{category.count}</span>
                </div>
              ))}
              {data.jobCategories.length === 0 && (
                <div className="text-gray-500 text-center py-4">No categories available</div>
              )}
            </div>
          </div>

          {/* Job Types */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Job Types</h2>
            <div className="space-y-2">
              {data.jobTypeDistribution.map((type, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-gray-600">{type.job_type}</span>
                  <span className="font-medium">{type.count}</span>
                </div>
              ))}
              {data.jobTypeDistribution.length === 0 && (
                <div className="text-gray-500 text-center py-4">No job types available</div>
              )}
            </div>
          </div>

          {/* Salary Ranges */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Salary Ranges</h2>
            <div className="space-y-2">
              {data.salaryRanges.map((salary, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-gray-600">{salary.range}</span>
                  <span className="font-medium">{salary.count}</span>
                </div>
              ))}
              {data.salaryRanges.length === 0 && (
                <div className="text-gray-500 text-center py-4">No salary data available</div>
              )}
            </div>
          </div>

          {/* Monthly Trends */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Monthly Activity</h2>
            <div className="space-y-2">
              {data.monthlyTrends.map((month, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-gray-600">{month.month}</span>
                  <div className="text-right">
                    <div>Applications: <span className="font-medium">{month.applications}</span></div>
                    <div>Jobs: <span className="font-medium">{month.jobs}</span></div>
                  </div>
                </div>
              ))}
              {data.monthlyTrends.length === 0 && (
                <div className="text-gray-500 text-center py-4">No monthly data available</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ title, value, icon }: { title: string; value: string | number; icon: React.ReactNode }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center justify-between">
        {icon}
        <div className="text-right">
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="mt-2 text-3xl font-semibold text-gray-900">{value}</p>
        </div>
      </div>
    </div>
  );
}