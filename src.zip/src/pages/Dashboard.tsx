import React from 'react';
import { DashboardStats } from '../components/dashboard/DashboardStats';
import { JobList } from '../components/JobList';
import { useJobs } from '../context/JobContext';
import { Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function Dashboard() {
  const { jobs } = useJobs();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const recentJobs = jobs.slice(0, 3);

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Welcome to JobConnect</h1>
          {isAdmin && (
            <button
              onClick={() => navigate('/jobs/new')}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-5 w-5 mr-2" />
              Post New Job
            </button>
          )}
        </div>

        <div className="mt-8">
          <DashboardStats />
        </div>

        <div className="mt-8">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Recent Job Postings</h2>
          <JobList jobs={recentJobs} onEdit={(job) => navigate(`/jobs/${job.job_id}/edit`)} onDelete={() => {}} />
          {jobs.length > 3 && (
            <div className="mt-4 text-center">
              <button
                onClick={() => navigate('/jobs')}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                View all jobs
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}