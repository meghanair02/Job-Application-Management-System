import React, { useState, useEffect } from 'react';
import { SeekerSearch } from '../components/SeekerSearch';

interface Application {
  application_id: string;
  job_id: string;
  seeker_id: string;
  application_status: string;
  application_date: string;
  job_title: string;
  first_name: string;
  last_name: string;
  email: string;
}

export function Applications() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      console.log('Fetching applications...');
      const response = await fetch('http://localhost:3000/api/applications');
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to fetch applications');
      }
      
      const data = await response.json();
      console.log('Received applications data:', data);
      
      if (data.applications && Array.isArray(data.applications)) {
        setApplications(data.applications);
      } else {
        console.error('Invalid applications data format:', data);
        setError('Invalid data format received from server');
      }
    } catch (err) {
      console.error('Error fetching applications:', err);
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center items-center h-64">Loading...</div>;
  if (error) return <div className="text-red-600 text-center">{error}</div>;

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Applications</h1>
          <div className="text-sm text-gray-600">
            Total Applications: <span className="font-medium">{applications.length}</span>
          </div>
        </div>

        {/* Search Section */}
        <div className="mb-8">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Search Applicants</h2>
          <SeekerSearch />
        </div>

        {/* Applications List */}
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <ul className="divide-y divide-gray-200">
            {applications.map((application) => (
              <li key={application.application_id} className="hover:bg-gray-50">
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">
                        {application.job_title}
                      </h3>
                      <p className="mt-1 text-sm text-gray-500">
                        {application.first_name} {application.last_name}
                      </p>
                    </div>
                    <div className="text-sm text-gray-500">
                      Applied: {new Date(application.application_date).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="text-sm text-gray-500">
                      <span className="font-medium">Email:</span> {application.email}
                    </div>
                    <div className="mt-2 sm:mt-0">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        {application.application_status}
                      </span>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {applications.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No applications found
          </div>
        )}
      </div>
    </div>
  );
}