import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

interface ChartProps {
  jobCategories: Array<{ category_name: string; count: number }>;
  applicationTrends: Array<{ date: string; count: number }>;
}

export function AnalyticsCharts({ jobCategories, applicationTrends }: ChartProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Job Categories Chart */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Jobs by Category</h2>
        <PieChart width={400} height={300}>
          <Pie
            data={jobCategories}
            dataKey="count"
            nameKey="category_name"
            cx="50%"
            cy="50%"
            outerRadius={100}
            label
          >
            {jobCategories.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </div>

      {/* Application Trends Chart */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Application Trends</h2>
        <BarChart width={400} height={300} data={applicationTrends}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="count" fill="#8884d8" name="Applications" />
        </BarChart>
      </div>
    </div>
  );
} 