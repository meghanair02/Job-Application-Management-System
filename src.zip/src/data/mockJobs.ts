import { Job } from '../types/job';

export const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior React Developer',
    company: 'TechCorp',
    location: 'San Francisco, CA',
    type: 'Full-time',
    description: 'Looking for an experienced React developer to join our team. The ideal candidate will have strong experience with modern React practices, state management, and performance optimization.',
    salary: '$120,000 - $150,000',
    postedDate: '2024-03-15',
    status: 'Open',
    skills: ['React', 'TypeScript', 'Redux', 'Node.js'],
    companyLogo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop',
    applicationCount: 12
  },
  {
    id: '2',
    title: 'UX Designer',
    company: 'DesignHub',
    location: 'Remote',
    type: 'Contract',
    description: 'Seeking a talented UX designer for our product team. Must have experience with user research, wireframing, and prototyping.',
    salary: '$90,000 - $110,000',
    postedDate: '2024-03-14',
    status: 'Open',
    skills: ['Figma', 'User Research', 'Prototyping', 'UI Design'],
    companyLogo: 'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=100&h=100&fit=crop',
    applicationCount: 8
  }
];