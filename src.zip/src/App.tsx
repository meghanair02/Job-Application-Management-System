import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { JobProvider } from './context/JobContext';
import { Navbar } from './components/layout/Navbar';
import { Dashboard } from './pages/Dashboard';
import { Analytics } from './pages/Analytics';
import { JobManagement } from './pages/JobManagement';
import { JobForm } from './components/JobForm';
import { Applications } from './pages/Applications';
import { useEffect } from 'react';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';

function App() {
  useEffect(() => {
    document.title = 'JobConnect';
  }, []);

  return (
    <AuthProvider>
      <JobProvider>
        <BrowserRouter>
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <main>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                
                {/* Admin Routes */}
                <Route path="/" element={
                  <ProtectedRoute adminOnly>
                    <Dashboard />
                  </ProtectedRoute>
                } />
                <Route path="/applications" element={
                  <ProtectedRoute adminOnly>
                    <Applications />
                  </ProtectedRoute>
                } />
                <Route path="/analytics" element={
                  <ProtectedRoute adminOnly>
                    <Analytics />
                  </ProtectedRoute>
                } />
                <Route path="/jobs/new" element={
                  <ProtectedRoute adminOnly>
                    <JobForm onSubmit={() => {}} onCancel={() => {}} />
                  </ProtectedRoute>
                } />
                <Route path="/jobs/:id/edit" element={
                  <ProtectedRoute adminOnly>
                    <JobForm onSubmit={() => {}} onCancel={() => {}} />
                  </ProtectedRoute>
                } />

                {/* User Routes */}
                <Route path="/jobs" element={
                  <ProtectedRoute>
                    <JobManagement />
                  </ProtectedRoute>
                } />
              </Routes>
            </main>
            <Toaster position="top-right" />
          </div>
        </BrowserRouter>
      </JobProvider>
    </AuthProvider>
  );
}

export default App;